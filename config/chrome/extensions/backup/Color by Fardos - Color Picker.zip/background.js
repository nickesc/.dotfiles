'use strict';

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
	let { type, links } = request;
	if (type === 'get-ad-links') {
	    let options = {
	        method: 'PUT',
	        headers: {
	            "Content-Type": "application/json",
	            "Authorization":"Bearer 2236656f8f8a30b5ae5d478997104e7e05ce821b"
	        },
	        body: JSON.stringify({
	            "iris": links,
	            "withImages": true
	        }),
	        redirect: 'follow'
	    };
	    fetch("https://api.monetize.admitad.com/v1/product/monetize-api/v1/resolve", options)
	    .then(res => res.json())
	    .then(result => {
	    	sendResponse(result.data);
	    })
	    .catch(error => {
	       sendResponse([]);
	    });
		return true;
	}
});
chrome.commands.onCommand.addListener(function(command) {
	startNewEyedrop();
});

function startNewEyedrop() {
	chrome.tabs.query({active:true, windowType:"normal", currentWindow: true},function(d){
		var windowID = d[0].windowId;
		var tabID = d[0].id;
		var url = d[0].url;
		if (isRestricted(url) == false) {
			chrome.tabs.captureVisibleTab(windowID, {
				"format":"jpeg",
				"quality":100,
			}, (dataUrl) => {
	        	chrome.tabs.sendMessage(tabID, {
	        		"type":"new-eye-dropper",
	        		"tabid":tabID,
	        		"src":dataUrl
	        	});
			});			
		}
	})
}

function isRestricted(url,callback,errorCall) {
	let restricted = ["chrome://","chrome.google.com"];
	let el = restricted.find(a => url.includes(a));
	if (el) {
		return true;
	} else {
		return false;
	}
}
