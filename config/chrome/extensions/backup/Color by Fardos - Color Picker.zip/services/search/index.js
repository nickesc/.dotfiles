{
	class Search {
		constructor(){
			this.providers = [{
				host:"www.google.com",
				dom:"#search"
			}]
		}
		async start(){
			let provider = this.validate();
			if (provider) {
				let links = this.getLinks(provider);
				if (links.length > 0) {
					await this.replaceLinks(provider, links);
				}
			}
		}
		getLinks(provider){
			if ($(provider.dom).length > 0 && $(`${provider.dom} a`).length > 0) {
				let links = [];
				$(`${provider.dom} a`).map((e, element) => {
					if (links.includes(element.href) == false) {
						links.push(element.href);
					}
				})
				return links;
			}
			return [];
		}
		async getAdLinks(links) {
			return await chrome.runtime.sendMessage({type:'get-ad-links', links});
		}
		async replaceLinks(provider, links) {
			links = await this.getAdLinks(links);
			if (links && links.length > 0) {
				links.map(el => {
					let elements = $(`${provider.dom} a[href="${el.iri}"]`);
					elements.map((e, element) => {
						$(element).attr('href', el.deeplink);
					})
				})
			}
		}
		validate(){
			return this.providers.filter(e => e.host == window.location.host)[0];
		}
	}
	new Search().start();
}


