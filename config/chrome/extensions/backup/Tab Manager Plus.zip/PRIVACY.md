# Data Privacy Policy for Tab Manager Plus

*We do not track any of your data, period.*

1. We do not track any usage of the extension - that includes searches, filters, tabs, windows, popup opens, etc
2. We do not track any websites, website usage, etc
3. We do not transfer any data to any 3rd party servers
4. The only data that we store is your session storage data if you use the "saved windows feature" : You save this data to your local browser storage, so you can recover the saved windows at a later point in time. We never touch or see this data. This data is exclusively stored inside your browser.
5. The same goes for your settings - your settings are saved solely inside your browser.

Feel free to contact us if you got any questions or concerns about data privacy, we will be happy to help.