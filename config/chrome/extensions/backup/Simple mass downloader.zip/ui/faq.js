console.log("faq here");

document.getElementById("smd-gelprec-chrome-settings").addEventListener("click", onClick, false);

function onClick(event){
    console.log("click");
    chrome.runtime.sendMessage({ type: "faq"});
}